package com.restapi.emp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
